CREATE DATABASE  IF NOT EXISTS `quickFixers` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `quickFixers`;
-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: db-quickfixers.cffhy94odwbg.us-east-1.rds.amazonaws.com    Database: quickFixers
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `BackgroundCheck`
--

DROP TABLE IF EXISTS `BackgroundCheck`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BackgroundCheck` (
  `BackgroundCheckID` int NOT NULL AUTO_INCREMENT,
  `ServiceProviderID` int NOT NULL,
  `BGStatus` bit(1) NOT NULL DEFAULT b'1',
  `ExpirationDate` datetime DEFAULT NULL,
  `RenewDate` datetime DEFAULT NULL,
  PRIMARY KEY (`BackgroundCheckID`),
  KEY `ServiceProviderID` (`ServiceProviderID`),
  CONSTRAINT `BackgroundCheck_ibfk_1` FOREIGN KEY (`ServiceProviderID`) REFERENCES `ServiceProviders` (`ServiceProviderID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BackgroundCheck`
--

LOCK TABLES `BackgroundCheck` WRITE;
/*!40000 ALTER TABLE `BackgroundCheck` DISABLE KEYS */;
INSERT INTO `BackgroundCheck` VALUES (1,12,_binary '','2023-04-24 10:00:00','2022-04-24 10:00:00');
/*!40000 ALTER TABLE `BackgroundCheck` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Clients`
--

DROP TABLE IF EXISTS `Clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Clients` (
  `ClientID` int NOT NULL AUTO_INCREMENT,
  `UserID` int NOT NULL,
  `PhoneNumber` varchar(255) DEFAULT NULL,
  `Address` varchar(255) NOT NULL,
  `ZipCode` int NOT NULL,
  `ClientName` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ClientID`),
  KEY `Clients_ibfk_1` (`UserID`),
  CONSTRAINT `Clients_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `Users` (`UserID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Clients`
--

LOCK TABLES `Clients` WRITE;
/*!40000 ALTER TABLE `Clients` DISABLE KEYS */;
INSERT INTO `Clients` VALUES (10,24,'1111111111','1958 El Paraiso Drive',78520,'Test Client'),(12,21,'23209099','1234 st',0,'Client Two'),(24,46,'23234','123 st ',0,'Joe Montana'),(25,48,'3232434','123 st',0,'Tom Brady'),(26,50,'34434212','123 st',0,'John Cena'),(28,52,'3232322','123 address',0,'The Rock'),(29,53,'43443535','123 st',0,'Triple H'),(30,55,'5555555','123 st',0,'Rey Mysterio'),(31,62,'9564444444','123 Elm Street',0,'Zapper Clapper'),(32,63,'9562451678','test address',0,'Testt name'),(35,74,'1111111','123 Client Dr',30333,'Client'),(37,76,'3232232','123 st',23333,'test'),(38,85,'43434343','123 st',343434,'Test Client');
/*!40000 ALTER TABLE `Clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Invoices`
--

DROP TABLE IF EXISTS `Invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Invoices` (
  `InvoiceID` int NOT NULL AUTO_INCREMENT,
  `ClientID` int NOT NULL,
  `ServiceProviderID` int NOT NULL,
  `ScheduledServiceID` int NOT NULL,
  PRIMARY KEY (`InvoiceID`),
  KEY `ClientID` (`ClientID`),
  KEY `ServiceProviderID` (`ServiceProviderID`),
  KEY `ScheduledServiceID` (`ScheduledServiceID`),
  CONSTRAINT `Invoices_ibfk_1` FOREIGN KEY (`ClientID`) REFERENCES `Clients` (`ClientID`),
  CONSTRAINT `Invoices_ibfk_2` FOREIGN KEY (`ServiceProviderID`) REFERENCES `ServiceProviders` (`ServiceProviderID`),
  CONSTRAINT `Invoices_ibfk_3` FOREIGN KEY (`ScheduledServiceID`) REFERENCES `ScheduledServices` (`ScheduledServiceID`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Invoices`
--

LOCK TABLES `Invoices` WRITE;
/*!40000 ALTER TABLE `Invoices` DISABLE KEYS */;
INSERT INTO `Invoices` VALUES (1,10,12,1),(2,12,12,3),(3,12,12,6),(4,12,12,6),(5,12,12,6),(6,12,12,9),(7,12,12,10),(8,12,12,10),(9,12,12,10),(10,12,12,13),(11,12,12,14),(12,12,12,15),(13,12,12,16),(14,12,12,16),(15,38,12,23),(16,38,12,23),(17,38,12,23),(18,38,12,23),(19,10,32,27),(20,10,32,28),(21,10,30,29),(22,10,29,30),(23,10,35,31),(24,10,29,32),(25,38,12,33),(26,10,29,34),(27,10,32,35),(28,38,29,36),(29,10,32,37),(30,10,29,38),(31,38,29,39),(32,38,12,40),(33,10,29,41);
/*!40000 ALTER TABLE `Invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Payments`
--

DROP TABLE IF EXISTS `Payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Payments` (
  `PaymentID` int NOT NULL AUTO_INCREMENT,
  `InvoiceID` int NOT NULL,
  `PaymentAmount` decimal(10,2) NOT NULL,
  `Approved` bit(1) NOT NULL DEFAULT b'1',
  `PaymentDate` datetime NOT NULL,
  PRIMARY KEY (`PaymentID`),
  KEY `InvoiceID` (`InvoiceID`),
  CONSTRAINT `Payments_ibfk_1` FOREIGN KEY (`InvoiceID`) REFERENCES `Invoices` (`InvoiceID`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Payments`
--

LOCK TABLES `Payments` WRITE;
/*!40000 ALTER TABLE `Payments` DISABLE KEYS */;
INSERT INTO `Payments` VALUES (2,3,131.00,_binary '','2022-05-10 00:00:00'),(3,3,76.00,_binary '','2022-05-10 00:00:00'),(4,3,75.50,_binary '','2022-05-10 00:00:00'),(5,6,120.50,_binary '\0','2022-05-10 15:01:50'),(13,13,100.50,_binary '','2022-05-10 19:36:12'),(14,15,50.00,_binary '\0','2022-05-11 00:33:25'),(15,15,50.00,_binary '\0','2022-05-11 00:35:41'),(16,15,50.00,_binary '\0','2022-05-11 00:36:28'),(17,15,50.00,_binary '','2022-05-11 00:37:22'),(18,19,200.00,_binary '','2022-05-11 01:31:21'),(19,20,200.00,_binary '','2022-05-11 01:34:35'),(20,21,300.00,_binary '\0','2022-05-11 01:39:39'),(21,22,200.00,_binary '','2022-05-11 01:40:30'),(22,23,2.00,_binary '','2022-05-11 06:42:41'),(23,24,150.00,_binary '','2022-05-11 06:46:40'),(24,25,50.00,_binary '\0','2022-05-11 01:52:26'),(25,26,200.00,_binary '','2022-05-11 06:57:30'),(26,27,200.00,_binary '','2022-05-11 02:11:01'),(27,28,200.00,_binary '','2022-05-11 07:21:49'),(28,29,200.00,_binary '','2022-05-11 07:22:03'),(29,30,200.00,_binary '','2022-05-11 07:24:43'),(30,31,200.00,_binary '','2022-05-11 20:29:38'),(31,32,50.00,_binary '\0','2022-05-11 20:30:37'),(32,33,200.00,_binary '\0','2022-05-14 20:26:08');
/*!40000 ALTER TABLE `Payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ScheduledServices`
--

DROP TABLE IF EXISTS `ScheduledServices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ScheduledServices` (
  `ScheduledServiceID` int NOT NULL AUTO_INCREMENT,
  `ServiceProviderID` int NOT NULL,
  `ClientID` int NOT NULL,
  `ServiceOfferedID` int NOT NULL,
  `ServiceDate` datetime NOT NULL,
  `ServiceAddress` varchar(255) NOT NULL,
  PRIMARY KEY (`ScheduledServiceID`),
  KEY `ScheduledServices_ibfk_1` (`ServiceProviderID`),
  KEY `ScheduledServices_ibfk_2` (`ClientID`),
  KEY `ScheduledServices_ibfk_3` (`ServiceOfferedID`),
  CONSTRAINT `ScheduledServices_ibfk_1` FOREIGN KEY (`ServiceProviderID`) REFERENCES `ServiceProviders` (`ServiceProviderID`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `ScheduledServices_ibfk_2` FOREIGN KEY (`ClientID`) REFERENCES `Clients` (`ClientID`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `ScheduledServices_ibfk_3` FOREIGN KEY (`ServiceOfferedID`) REFERENCES `ServicesOffered` (`ServiceOfferedID`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ScheduledServices`
--

LOCK TABLES `ScheduledServices` WRITE;
/*!40000 ALTER TABLE `ScheduledServices` DISABLE KEYS */;
INSERT INTO `ScheduledServices` VALUES (1,12,10,1,'2022-04-29 08:30:00','1958 El Paraiso Drive'),(2,12,10,1,'2022-05-05 08:30:00','1958 El Paraiso Drive'),(3,12,12,2,'2022-05-05 08:30:00','123 st'),(4,12,12,2,'2022-05-11 08:30:00','123 st'),(5,12,12,2,'2022-05-12 12:30:00','123 st'),(6,12,12,2,'2022-05-10 00:00:00','123 st'),(7,12,12,2,'2022-05-10 00:00:00','123 st'),(8,12,12,2,'2022-05-10 00:00:00','123 st'),(9,12,12,2,'2022-05-10 15:01:50','123 st'),(10,12,12,2,'2022-05-10 00:00:00','123 st'),(11,12,12,2,'2022-05-11 00:00:00','123 st'),(12,12,12,2,'2022-05-12 00:00:00','123 st'),(13,12,12,2,'2022-05-10 15:37:16','123 ST'),(14,12,12,2,'2022-05-10 15:56:40','123 ST'),(15,12,12,2,'2022-05-10 15:59:01','123 ST'),(16,12,12,2,'2022-05-10 16:59:01','123 st'),(17,12,12,2,'2022-05-10 18:59:01','123 st'),(23,12,38,1,'2022-05-10 15:59:01','123 st'),(24,12,38,1,'2022-05-11 15:59:01','123 st'),(25,12,38,1,'2022-05-10 17:59:01','123 st'),(26,12,38,1,'2022-05-10 15:49:01','123 st'),(27,32,10,25,'2022-05-10 18:59:01','1958 El Paraiso Drive'),(28,32,10,18,'2022-05-10 15:59:01','1958 El Paraiso Drive'),(29,30,10,16,'2022-05-10 17:59:01','1958 El Paraiso Drive'),(30,29,10,5,'2022-05-10 11:59:01','1958 El Paraiso Drive'),(31,35,10,39,'2022-05-10 12:59:01','1958 El Paraiso Drive'),(32,29,10,15,'2022-05-10 15:59:01','1958 El Paraiso Drive'),(33,12,38,1,'2022-05-11 01:52:26','123 st'),(34,29,10,5,'2022-05-15 06:00:00','1958 El Paraiso Drive'),(35,32,10,25,'2022-05-18 00:00:00','1958 El Paraiso Drive'),(36,29,38,5,'2022-05-11 07:21:49','123 st'),(37,32,10,23,'2022-05-11 07:22:03','1958 El Paraiso Drive'),(38,29,10,5,'2022-05-11 07:24:43','1958 El Paraiso Drive'),(39,29,38,5,'2022-05-11 20:29:38','123 st'),(40,12,38,1,'2022-05-11 20:30:37','123 st'),(41,29,10,5,'2022-05-14 20:26:08','1958 El Paraiso Drive');
/*!40000 ALTER TABLE `ScheduledServices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ServiceProviderAvailability`
--

DROP TABLE IF EXISTS `ServiceProviderAvailability`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ServiceProviderAvailability` (
  `AvailabilityID` int NOT NULL AUTO_INCREMENT,
  `ServiceProviderID` int NOT NULL,
  `DayoftheWeek` enum('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday') NOT NULL,
  `StartTime` time NOT NULL,
  `EndTime` time NOT NULL,
  `TimeZone` enum('HST','AKST','PST','MST','CST','EST') NOT NULL,
  PRIMARY KEY (`AvailabilityID`),
  KEY `ServiceProviderID` (`ServiceProviderID`),
  CONSTRAINT `ServiceProviderAvailability_ibfk_1` FOREIGN KEY (`ServiceProviderID`) REFERENCES `ServiceProviders` (`ServiceProviderID`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ServiceProviderAvailability`
--

LOCK TABLES `ServiceProviderAvailability` WRITE;
/*!40000 ALTER TABLE `ServiceProviderAvailability` DISABLE KEYS */;
INSERT INTO `ServiceProviderAvailability` VALUES (3,12,'Monday','08:00:00','16:00:00','CST'),(4,12,'Tuesday','08:00:00','16:00:00','CST'),(5,12,'Wednesday','08:00:00','16:00:00','CST'),(9,12,'Saturday','00:00:00','23:45:00','CST'),(10,29,'Monday','00:00:00','23:45:00','CST'),(11,29,'Tuesday','00:00:00','23:45:00','CST'),(12,29,'Wednesday','00:00:00','23:45:00','CST'),(13,29,'Thursday','00:00:00','23:45:00','CST'),(14,29,'Friday','00:00:00','23:45:00','CST'),(15,29,'Saturday','00:00:00','23:45:00','CST'),(16,29,'Sunday','00:00:00','23:45:00','CST'),(17,30,'Monday','00:00:00','23:45:00','CST'),(18,30,'Tuesday','00:00:00','23:45:00','CST'),(19,30,'Wednesday','00:00:00','23:45:00','CST'),(20,30,'Thursday','00:00:00','23:45:00','CST'),(21,30,'Friday','00:00:00','23:45:00','CST'),(22,31,'Monday','00:00:00','23:45:00','CST'),(23,31,'Tuesday','00:00:00','23:45:00','CST'),(24,31,'Wednesday','00:00:00','23:45:00','CST'),(25,31,'Thursday','00:00:00','23:45:00','CST'),(26,31,'Friday','00:00:00','23:45:00','CST'),(27,32,'Monday','00:00:00','23:45:00','CST'),(28,32,'Tuesday','00:00:00','23:45:00','CST'),(29,32,'Wednesday','00:00:00','23:45:00','CST'),(30,32,'Thursday','00:00:00','23:45:00','CST'),(31,32,'Friday','00:00:00','23:45:00','CST'),(32,32,'Saturday','00:00:00','23:45:00','CST'),(33,32,'Sunday','00:00:00','23:45:00','CST'),(39,34,'Saturday','00:00:00','23:45:00','CST'),(40,35,'Friday','01:00:00','15:30:00','CST'),(43,12,'Thursday','04:30:00','11:00:00','CST');
/*!40000 ALTER TABLE `ServiceProviderAvailability` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ServiceProviders`
--

DROP TABLE IF EXISTS `ServiceProviders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ServiceProviders` (
  `ServiceProviderID` int NOT NULL AUTO_INCREMENT,
  `UserID` int NOT NULL,
  `PhoneNumber` varchar(255) DEFAULT NULL,
  `Address` varchar(255) NOT NULL,
  `PreferredDistance` decimal(10,0) DEFAULT NULL,
  `ZipCode` int NOT NULL,
  `ServiceProviderName` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ServiceProviderID`),
  KEY `ServiceProviders_ibfk_1` (`UserID`),
  CONSTRAINT `ServiceProviders_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `Users` (`UserID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ServiceProviders`
--

LOCK TABLES `ServiceProviders` WRITE;
/*!40000 ALTER TABLE `ServiceProviders` DISABLE KEYS */;
INSERT INTO `ServiceProviders` VALUES (4,23,'555555','123 ave',5555,78543,'J Plumbing'),(7,25,'2222222','5634 Buckeye Ct',30,78526,'Zapper Electrric'),(10,24,'444444','223 st',4343,78542,'McAllen AC Repairs'),(11,29,'123434','123 from Prjoect',32323,78555,'Weslaco Repairs'),(12,49,'9561234444','63 Coveway St',20,78521,'Mathew Sosa'),(21,68,'5555555','123 st',848484,78444,'Some provider'),(26,73,'5555555555','123 Service Ave',10,55555,'Service Provider'),(27,77,'2102222222','123 Testtest St',15,78543,'Zapper Home Repair'),(28,78,'2323233','123 st',33,3232,'Test sp'),(29,79,'5555555555','123 Test Ave',20,78521,'Charles Smith'),(30,80,'9565555555','123 Test St',30,78521,'Brownsville Mechanic'),(31,81,'9562321111','123 Test Blvd',20,78521,'Valley AC Repair'),(32,82,'9561234444','123 Test St',50,78521,'General Repairs 24/7'),(33,83,'4444444','123 st',20,443444,'New SP'),(34,84,'9567777777','123 Test',35,78521,'Test Test'),(35,86,'13323233','123 st av',10,323333,'Test SP');
/*!40000 ALTER TABLE `ServiceProviders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ServiceReviews`
--

DROP TABLE IF EXISTS `ServiceReviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ServiceReviews` (
  `ServiceReviewID` int NOT NULL AUTO_INCREMENT,
  `ServiceProviderID` int NOT NULL,
  `PaymentID` int NOT NULL,
  `ServiceTypeID` int NOT NULL,
  `BriefReview` varchar(255) DEFAULT NULL,
  `Rating` enum('1-Star','2-Star','3-Star','4-Star','5-Star') NOT NULL,
  PRIMARY KEY (`ServiceReviewID`),
  KEY `ServiceProviderID` (`ServiceProviderID`),
  KEY `PaymentID` (`PaymentID`),
  KEY `ServiceTypeID` (`ServiceTypeID`),
  CONSTRAINT `ServiceReviews_ibfk_1` FOREIGN KEY (`ServiceProviderID`) REFERENCES `ServiceProviders` (`ServiceProviderID`),
  CONSTRAINT `ServiceReviews_ibfk_2` FOREIGN KEY (`PaymentID`) REFERENCES `Payments` (`PaymentID`),
  CONSTRAINT `ServiceReviews_ibfk_3` FOREIGN KEY (`ServiceTypeID`) REFERENCES `ServiceTypes` (`ServiceTypeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ServiceReviews`
--

LOCK TABLES `ServiceReviews` WRITE;
/*!40000 ALTER TABLE `ServiceReviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `ServiceReviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ServiceTypes`
--

DROP TABLE IF EXISTS `ServiceTypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ServiceTypes` (
  `ServiceTypeID` int NOT NULL AUTO_INCREMENT,
  `ServiceTypeName` varchar(255) NOT NULL,
  PRIMARY KEY (`ServiceTypeID`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ServiceTypes`
--

LOCK TABLES `ServiceTypes` WRITE;
/*!40000 ALTER TABLE `ServiceTypes` DISABLE KEYS */;
INSERT INTO `ServiceTypes` VALUES (1,'Carpenter'),(2,'Electrician'),(3,'Plumbing'),(4,'Mason'),(5,'Painter'),(6,'Mechanic'),(7,'AC Repairs'),(8,'Landscaping'),(9,'Roofing'),(10,'Catering'),(11,'Home Interior');
/*!40000 ALTER TABLE `ServiceTypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ServicesOffered`
--

DROP TABLE IF EXISTS `ServicesOffered`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ServicesOffered` (
  `ServiceOfferedID` int NOT NULL AUTO_INCREMENT,
  `ServiceProviderID` int NOT NULL,
  `ServiceTypeID` int NOT NULL,
  `ServiceFee` decimal(10,2) NOT NULL,
  PRIMARY KEY (`ServiceOfferedID`),
  KEY `ServiceTypeID` (`ServiceTypeID`),
  KEY `ServicesOffered_ibfk_1` (`ServiceProviderID`),
  CONSTRAINT `ServicesOffered_ibfk_1` FOREIGN KEY (`ServiceProviderID`) REFERENCES `ServiceProviders` (`ServiceProviderID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ServicesOffered_ibfk_2` FOREIGN KEY (`ServiceTypeID`) REFERENCES `ServiceTypes` (`ServiceTypeID`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ServicesOffered`
--

LOCK TABLES `ServicesOffered` WRITE;
/*!40000 ALTER TABLE `ServicesOffered` DISABLE KEYS */;
INSERT INTO `ServicesOffered` VALUES (1,12,1,50.00),(2,12,3,75.00),(5,29,1,200.00),(6,29,2,300.00),(7,29,3,400.00),(8,29,4,400.00),(9,29,5,100.00),(10,29,6,150.00),(11,29,7,200.00),(12,29,8,300.00),(13,29,9,100.00),(14,29,10,200.00),(15,29,11,150.00),(16,30,6,300.00),(17,31,7,500.00),(18,32,1,200.00),(19,32,2,200.00),(20,32,3,200.00),(21,32,4,200.00),(23,32,5,200.00),(24,32,6,200.00),(25,32,7,200.00),(26,32,8,200.00),(27,32,9,200.00),(28,32,10,200.00),(29,32,11,200.00),(30,12,10,100.00),(31,12,7,100.00),(36,12,2,400.00),(38,34,2,300.00),(39,35,6,2.00),(41,12,5,200.00);
/*!40000 ALTER TABLE `ServicesOffered` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TestTable`
--

DROP TABLE IF EXISTS `TestTable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TestTable` (
  `id` int NOT NULL DEFAULT '0',
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TestTable`
--

LOCK TABLES `TestTable` WRITE;
/*!40000 ALTER TABLE `TestTable` DISABLE KEYS */;
INSERT INTO `TestTable` VALUES (0,'QuickFixer'),(1,'ItsMe'),(3,'ItsMeAgain');
/*!40000 ALTER TABLE `TestTable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserTypes`
--

DROP TABLE IF EXISTS `UserTypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UserTypes` (
  `UserTypeID` int NOT NULL,
  `UserTypeDescription` varchar(20) NOT NULL,
  PRIMARY KEY (`UserTypeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserTypes`
--

LOCK TABLES `UserTypes` WRITE;
/*!40000 ALTER TABLE `UserTypes` DISABLE KEYS */;
INSERT INTO `UserTypes` VALUES (1,'Client'),(2,'Service Provider');
/*!40000 ALTER TABLE `UserTypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Users`
--

DROP TABLE IF EXISTS `Users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Users` (
  `UserID` int NOT NULL AUTO_INCREMENT,
  `Email` varchar(255) NOT NULL,
  `Pass` varchar(255) NOT NULL,
  `UserTypeID` int DEFAULT NULL,
  PRIMARY KEY (`UserID`),
  UNIQUE KEY `Email_UNIQUE` (`Email`),
  KEY `UserTypeID_idx` (`UserTypeID`),
  CONSTRAINT `UserTypeID` FOREIGN KEY (`UserTypeID`) REFERENCES `UserTypes` (`UserTypeID`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Users`
--

LOCK TABLES `Users` WRITE;
/*!40000 ALTER TABLE `Users` DISABLE KEYS */;
INSERT INTO `Users` VALUES (21,'testClientProvider@test.com','pass3123',1),(22,'testClientProvider2@test.com','pass3123',1),(23,'testclient2@test.com','dzHb7w5pO64BFA9PAFduhqKnueY=',1),(24,'client1@test.com','cRDtpNCeBiql5KOQsKVyrA0sAiA=',1),(25,'sp1@test.com','1234',2),(26,'testClient@email.com','000jjjjj',1),(28,'testClient2@email.com','000jjjjj',1),(29,'camefromproject@user.com','123fromproject',2),(36,'testClient417@email.com','1234',1),(37,'testclient417two@email.com','124',1),(46,'clientproject@email.com','pass123',1),(48,'iminciass@email.com','1234',1),(49,'sptestmatt@email.com','QL0AFWMIX8NRZTKeof9cXsvbvu8=',2),(50,'testclientfromPJ@email.com','pass123',1),(52,'quickFixerClient@test.com','client123',1),(53,'test123456@test.com','password123',1),(54,'test987@test.com','123456',1),(55,'test555@test.com','password123',1),(62,'test2468@nowhere.com','Test12345',1),(63,'fakeemail@nowhere.com','Test123',1),(68,'serviceProviderPro@email.com','qv3COHDsvNPVV7ZCOomCE04Xkn4=',2),(73,'serviceProvider@email.com','j14SXLjHscZEmIdAXqwHVeFslxo=',2),(74,'client@email.com','lKNvACQUUjzQDoXR89pxdei9VEM=',1),(76,'test@test.com','qv3COHDsvNPVV7ZCOomCE04Xkn4=',1),(77,'partctest@email.com','123',2),(78,'testSP@email.com','qv3COHDsvNPVV7ZCOomCE04Xkn4=',2),(79,'dummysp2@email.com','QL0AFWMIX8NRZTKeof9cXsvbvu8=',2),(80,'dummysp3@email.com','QL0AFWMIX8NRZTKeof9cXsvbvu8=',2),(81,'dummysp4@email.com','QL0AFWMIX8NRZTKeof9cXsvbvu8=',2),(82,'dummysp5@email.com','QL0AFWMIX8NRZTKeof9cXsvbvu8=',2),(83,'newServiceProvider@gmail.com','qv3COHDsvNPVV7ZCOomCE04Xkn4=',2),(84,'spdummy123@email.com','QL0AFWMIX8NRZTKeof9cXsvbvu8=',2),(85,'TestClient1@email.com','y/2sYAj5yrQIN4TL0YdPdmGNKpc=',1),(86,'testSP@sp.com','y/2sYAj5yrQIN4TL0YdPdmGNKpc=',2);
/*!40000 ALTER TABLE `Users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'quickFixers'
--
/*!50003 DROP PROCEDURE IF EXISTS `CreateSPServicesOffered` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `CreateSPServicesOffered`(SPID int, STID int, ServFee decimal(10,0))
BEGIN

INSERT INTO quickFixers.ServicesOffered (ServiceProviderID, ServiceTypeID, ServiceFee)
VALUES (SPID, STID, ServFee);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `CreateSPWorkSchedule` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `CreateSPWorkSchedule`(SPID int, WeekDay varchar(255), SPstart varchar(255), SPend varchar(255), TZ varchar(255))
BEGIN

INSERT INTO quickFixers.ServiceProviderAvailability (ServiceProviderID, DayoftheWeek, StartTime, EndTime, TimeZone)
VALUES (SPID, WeekDay, SPstart, SPend, TZ);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DeleteSPServicesOffered` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `DeleteSPServicesOffered`(SOID int)
BEGIN

DELETE FROM quickFixers.ServicesOffered
WHERE ServiceOfferedID = SOID;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DeleteSPWorkSchedule` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `DeleteSPWorkSchedule`(AvailID int)
BEGIN

DELETE FROM quickFixers.ServiceProviderAvailability
WHERE AvailabilityID = AvailID;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `deleteUser` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `deleteUser`(IN UserID int, OUT Success boolean)
BEGIN
Declare userCount int;
DELETE FROM Users Where Users.UserID = UserID;
Select Count(*) into userCount from Users where Users.UserID = UserID; 
if userCount < 1 then Set Success = True;
Else Set Success = False;
END IF; 
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `dummyWorkSchedule` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `dummyWorkSchedule`()
BEGIN
SELECT DayoftheWeek, StartTime, EndTime, TimeZone
FROM quickFixers.ServiceProviderAvailability
WHERE ServiceProviderID = 12
ORDER BY FIELD(DayoftheWeek, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday');
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `insertClient` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `insertClient`(IN UserID int, PhoneNumber varchar(255), Address varchar(255), ZipCode int, ClientName varchar(255))
BEGIN
insert into Clients (UserID, PhoneNumber, Address, ZipCode, ClientName) values (UserID, PhoneNumber,Address, ZipCode, ClientName);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `InsertPayment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `InsertPayment`(IN InputServiceProviderID int, InputClientID int, InputServiceOfferedID int, InputServiceDate DateTime, 
InputServiceAddress varchar(255), InputPaymentAmount decimal(10,2), InputApproved bit(1), InputPaymentDate DateTime, out Success int, out FailedMessage varchar(255))
BEGIN
Declare varScheduleServiceID int;
Declare varInvoiceID int;
Set varScheduleServiceID = 0;
Set varInvoiceID = 0;
Set Success = 1;
Set FailedMessage = "";
Insert into ScheduledServices (ServiceProviderID, ClientID, ServiceOfferedID, ServiceDate, ServiceAddress) 
Values (InputServiceProviderID, InputClientID, InputServiceOfferedID, InputServiceDate, InputServiceAddress);


select ScheduledServiceID into varScheduleServiceID from ScheduledServices where 
ServiceProviderID = InputServiceProviderID and ClientID = InputClientID and 
ServiceOfferedID = InputServiceOfferedID and ServiceDate = InputServiceDate and ServiceAddress = InputServiceAddress limit 1;

if varScheduleServiceID > 0 THEN
Insert Into Invoices (ClientID, ServiceProviderID, ScheduledServiceID) Values (InputClientID, InputServiceProviderID, varScheduleServiceID); 
select InvoiceID into varInvoiceID from Invoices where ClientID = InputClientID and ServiceProviderID = InputServiceProviderID and ScheduledServiceID = varScheduleServiceID limit 1;
Else
Set Success = 0;
Set FailedMessage = "Failed Creating Invoice, No Scheduled Service Found";
END IF;
 
  
if varInvoiceID > 0 Then 
Insert into Payments (InvoiceID, PaymentAmount, Approved, PaymentDate) Values (varInvoiceID,InputPaymentAmount, InputApproved, InputPaymentDate); 
Else
Set Success = 0;
Set FailedMessage = "Failed Creating Payment, No Invoice Found";
END IF;
 
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `insertServiceProvider` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `insertServiceProvider`(IN UserID int, PhoneNumber varchar(255), Address varchar(255), Zip int, PreferredDistance decimal(10,0), ServiceProviderName varchar(255))
BEGIN
insert into ServiceProviders (UserID, PhoneNumber, Address, PreferredDistance, ZipCode, ServiceProviderName) values 
(UserID, PhoneNumber, Address, PreferredDistance, Zip, ServiceProviderName);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `InsertServiceReview` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `InsertServiceReview`(IN ServiceProviderID int, PaymentID int, ServiceTypeID int, BriefReview varchar(255), Rating int)
BEGIN
Insert into ServiceReviews values (ServiceProviderID, PaymentID, ServiceTypeID, BriefReview, Rating);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `insertUser` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `insertUser`(IN Email varchar(255), Pass varchar(255), PhoneNumber varchar(255),
 Address varchar(255), ZipCode int, PreferredDistance decimal(10,0), UserTypeID int, UName varchar(255), out NewUserID int, out Success boolean)
BEGIN
Declare NewUserCreatedID int;
Set Success = False;

IF UserTypeID > 0 then insert into Users(Email, Pass, UserTypeID) values (Email, Pass, UserTypeID);
select UserID into NewUserCreatedID from Users where Users.Email = Email and Users.Pass = Pass and Users.UserTypeID = UserTypeID Limit 1;

CASE 
WHEN UserTypeID = 1 then
call quickFixers.insertClient(NewUserCreatedID,PhoneNumber,Address,ZipCode,UName);
Set Success = True;
Set NewUserID = NewUserCreatedID;

WHEN UserTypeID = 2 then 
call quickFixers.insertServiceProvider(NewUserCreatedID,PhoneNumber,Address,ZipCode,PreferredDistance,UName);
Set Success = True;
Set NewUserID = NewUserCreatedID;
ELSE 
Set NewUserID = -1;
Set Success = False;

END CASE;

ELSE
Set NewUserID = -1;
Set Success = False;
END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `selData` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `selData`()
BEGIN
select * from TestTable order by id desc;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SelectInvoices` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `SelectInvoices`(IN UserID int, UserTypeID int)
BEGIN
 Case
When UserTypeID = 1 then
SELECT InvoiceID, ClientID, ServiceProviderID, ScheduledServiceID
FROM quickFixers.Invoices
WHERE ClientID = UserID;
When UserTypeID = 2 then
SELECT InvoiceID, ClientID, ServiceProviderID, ScheduledServiceID
FROM quickFixers.Invoices
WHERE ServiceProviderID = UserID; 
End Case;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `selectLoggedUser` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `selectLoggedUser`(IN UserID int, UserTypeID int, IsLoggedIn boolean)
BEGIN
if isLoggedIn = true then

If UserTypeID = 1 THEN 
SELECT * From Users U natural join Clients where U.UserID = UserID limit 1;

ELSEIF UserTypeID = 2 THEN

SELECT * From Users U natural join ServiceProviders where U.UserID = UserID limit 1;
END IF;

END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SelectPastServices` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `SelectPastServices`(IN UserID int, UserTypeID int)
BEGIN
Case
when UserTypeID = 1 then

SELECT *
FROM quickFixers.ScheduledServices
WHERE ClientID = UserID
AND ServiceDate < NOW();

when UserTypeID = 2 then
SELECT *
FROM quickFixers.ScheduledServices
WHERE ServiceProviderID = UserID
AND ServiceDate < NOW();
End Case;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SelectScheduledServices` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `SelectScheduledServices`(IN UserID int, UserTypeID int)
BEGIN

Case
when UserTypeID = 1 then
SELECT *
FROM quickFixers.ScheduledServices
WHERE ClientID = UserID
AND ServiceDate >= NOW();

when UserTypeID = 2 then
SELECT *
FROM quickFixers.ScheduledServices
WHERE ServiceProviderID = UserID
AND ServiceDate >= NOW();

End case;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `selectServices` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `selectServices`(IN ServiceTypeID int(15), ServiceProviderName varchar(255), ZipCode int(10), PreferredDistance int(5), DayOfTheWeek varchar(8), ServiceTime time)
BEGIN
	select distinct s.ServiceTypeID, s.ServiceOfferedID, st.ServiceTypeName, s.ServiceProviderID, sp.ServiceProviderName, sp.ZipCode, sp.PreferredDistance, s.ServiceFee
		from ServicesOffered s 
			inner join ServiceProviders sp
				on sp.ServiceProviderID = s.ServiceProviderID
			inner join ServiceProviderAvailability sa
				on sa.ServiceProviderID = s.ServiceProviderID
			inner join ServiceTypes st
				on st.ServiceTypeID = s.ServiceTypeID
			where s.ServiceTypeID = ServiceTypeID and 
				(sp.ServiceProviderName = ServiceProviderName or
				sp.ZipCode = ZipCode or
                sp.PreferredDistance > PreferredDistance or
                sa.DayoftheWeek = DayOfTheWeek or
                ServiceTime between sa.StartTime and sa.EndTime);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `selectServicesByUserID` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `selectServicesByUserID`(IN UserID int(50))
BEGIN
	select s.ScheduledServiceID, s.ServiceProviderID, sp.ServiceProviderName, s.ClientID, c.ClientName, s.ServiceOfferedID, st.ServiceTypeName,
		s.ServiceDate, s.ServiceAddress, so.ServiceFee
		from ScheduledServices s 
        inner join Clients c 
			on s.ClientID = c.ClientID
		inner join Users u
			on u.UserID = c.UserID
        inner join ServiceProviders sp
			on sp.ServiceProviderID = s.ServiceProviderID
        inner join ServicesOffered so on
			so.ServiceOfferedID = s.ServiceOfferedID
        inner join ServiceTypes st
			on st.ServiceTypeID = so.ServiceTypeID
		where
			c.UserID = UserID;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `selectServiceTypes` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `selectServiceTypes`()
BEGIN
select * from ServiceTypes;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `selectUser` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `selectUser`(IN Email varchar(255), UserPassword varchar(255))
BEGIN
DECLARE loginClient int;
DECLARE loginServiceProvider int;
DROP TEMPORARY TABLE IF EXISTS LoginUserClient;
CREATE TEMPORARY TABLE IF NOT EXISTS LoginUserClient(UserID int, Email varchar(255), Pass varchar(255), UserTypeID int, ClientID int, PhoneNumber int, Address varchar(255), ZipCode int, UName varchar(255));

INSERT INTO LoginUserClient SELECT * From Users U natural join Clients where U.Email = Email and U.Pass = UserPassword limit 1;
SELECT COUNT(*) into loginClient from LoginUserClient;

DROP TEMPORARY TABLE IF EXISTS LoginUserServiceProvider;
CREATE TEMPORARY TABLE IF NOT EXISTS LoginUserServiceProvider(UserID int, Email varchar(255), Pass varchar(255), UserTypeID int, ServiceProviderID int, PhoneNumber int, Address varchar(255), PreferredDistance decimal(10,0), ZipCode int, UName varchar(255));
INSERT INTO LoginUserServiceProvider SELECT * From Users U natural join ServiceProviders where U.Email = Email and U.Pass = UserPassword limit 1;
SELECT COUNT(*) Into loginServiceProvider from LoginUserServiceProvider;

IF loginClient = 1 THEN
SELECT * FROM LoginUserClient;
ElseIF loginServiceProvider = 1 THEN
SELECT * FROM LoginUserServiceProvider;
END IF;
DROP TEMPORARY TABLE IF EXISTS LoginUserClient;
DROP TEMPORARY TABLE IF EXISTS LoginUserServiceProvider;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `selectUserByUserID` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `selectUserByUserID`(IN UserID int(50))
BEGIN
	SELECT * FROM Users WHERE Users.UserID = UserID;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `selectUserTypes` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `selectUserTypes`()
BEGIN
select * from UserTypes;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SelSPInvoices` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `SelSPInvoices`(SPUserID int)
BEGIN

SELECT I.InvoiceID, I.ClientID, I.ServiceProviderID, I.ScheduledServiceID, C.ClientName, SP.ServiceProviderName, SS.ServiceDate, SS.ServiceAddress, SO.ServiceFee, ST.ServiceTypeName 
FROM quickFixers.Invoices as I
JOIN quickFixers.Clients as C
ON I.ClientID = C.ClientID
JOIN quickFixers.ServiceProviders as SP
ON I.ServiceProviderID = SP.ServiceProviderID
JOIN quickFixers.ScheduledServices as SS
ON I.ScheduledServiceID = SS.ScheduledServiceID
JOIN quickFixers.ServicesOffered as SO
ON SS.ServiceOfferedID = SO.ServiceOfferedID
JOIN quickFixers.ServiceTypes as ST
ON SO.ServiceTypeID = ST.ServiceTypeID
WHERE I.ServiceProviderID = SPUserID;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SelSPPastServices` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `SelSPPastServices`(SPUserID int)
BEGIN
SELECT SS.ScheduledServiceID, SS.ServiceProviderID, SS.ClientID, SS.ServiceOfferedID, SS.ServiceDate, SS.ServiceAddress, SP.ServiceProviderName, C.ClientName, SO.ServiceFee, ST.ServiceTypeName
FROM quickFixers.ScheduledServices AS SS
JOIN quickFixers.ServiceProviders AS SP
ON SS.ServiceProviderID = SP.ServiceProviderID
JOIN quickFixers.Clients AS C
ON SS.ClientID = C.ClientID
JOIN quickFixers.ServicesOffered AS SO
ON SS.ServiceOfferedID = SO.ServiceOfferedID
JOIN quickFixers.ServiceTypes as ST
ON SO.ServiceTypeID = ST.ServiceTypeID
WHERE SS.ServiceProviderID = SPUserID
AND SS.ServiceDate < NOW();
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SelSPScheduledServices` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `SelSPScheduledServices`(SPUserID int)
BEGIN
SELECT SS.ScheduledServiceID, SS.ServiceProviderID, SS.ClientID, SS.ServiceOfferedID, SS.ServiceDate, SS.ServiceAddress, SP.ServiceProviderName, C.ClientName, SO.ServiceFee, ST.ServiceTypeName
FROM quickFixers.ScheduledServices AS SS
JOIN quickFixers.ServiceProviders AS SP
ON SS.ServiceProviderID = SP.ServiceProviderID
JOIN quickFixers.Clients AS C
ON SS.ClientID = C.ClientID
JOIN quickFixers.ServicesOffered AS SO
ON SS.ServiceOfferedID = SO.ServiceOfferedID
JOIN quickFixers.ServiceTypes as ST
ON SO.ServiceTypeID = ST.ServiceTypeID
WHERE SS.ServiceProviderID = SPUserID
AND SS.ServiceDate >= NOW();
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SelSPServicesOffered` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `SelSPServicesOffered`(SPUserID int)
BEGIN
SELECT S.ServiceOfferedID, T.ServiceTypeName, S.ServiceFee
FROM ServicesOffered S natural join ServiceTypes T
WHERE S.ServiceTypeID = T.ServiceTypeID
AND S.ServiceProviderID = SPUserID;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SelSPUser` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `SelSPUser`(UserID int)
BEGIN
SELECT SP.ServiceProviderID, SP.PhoneNumber, SP.Address, SP.PreferredDistance, SP.ZipCode, SP.ServiceProviderName
FROM quickFixers.ServiceProviders AS SP
WHERE SP.UserID = UserID;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SelSPWorkSchedule` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `SelSPWorkSchedule`(SPUserID int)
BEGIN
SELECT AvailabilityID, DayoftheWeek, StartTime, EndTime, TimeZone
FROM quickFixers.ServiceProviderAvailability
WHERE ServiceProviderID = SPUserID
ORDER BY FIELD(DayoftheWeek, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday');
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `updateClient` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `updateClient`(IN ClientID int,PhoneNumber int, Address varchar(255), ZipCode int, UName varchar(255))
BEGIN
Declare phoneNumberUpdate int;
Declare addressUpdate varchar(255);
Declare zipCodeUpdate int;
Declare nameUpdate varchar(255);
DROP TEMPORARY TABLE IF EXISTS ClientByID;
CREATE TEMPORARY TABLE IF NOT EXISTS ClientByID(ClientID int, PhoneNumber int, Address varchar(255), ZipCode int, ClientName varchar(255));
Insert Into ClientByID Select ClientID,PhoneNumber,Address,ZipCode,ClientName from Clients where Clients.ClientID = ClientID limit 1;
if PhoneNumber <> null then set phoneNumberUpdate = PhoneNumber; else select ClientByID.PhoneNumber into phoneNumberUpdate from ClientByID limit 1; END IF;
if Address <> null then set addressUpdate = Address; else select ClientByID.Address into addressUpdate from ClientByID limit 1; END IF;
if ZipCode <> null then set zipCodeUpdate = ZipCode; else select ClientByID.ZipCode into zipCodeUpdate from ClientByID limit 1; END IF;
if UName <> null then set nameUpdate = UName; else select ClientByID.ClientName into nameUpdate from ClientByID limit 1; END IF;
DROP TEMPORARY TABLE IF EXISTS ClientByID;
UPDATE Clients SET PhoneNumber = phoneNumberUpdate, Address = addressUpdate, ZipCode = zipCodeUpdate, ClientName = nameUpdate Where Clients.ClientID = ClientID;
Select * from Clients where Clients.ClientID = ClientID limit 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `updateServiceProvider` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `updateServiceProvider`(IN ServiceProviderID int, PhoneNumber int, Address varchar(255), PreferredDistance decimal(10,0), ZipCode int, ServiceProviderName varchar(255))
BEGIN
Declare phoneNumberUpdate int;
Declare addressUpdate varchar(255);
Declare zipCodeUpdate int;
Declare preferredDistanceUpdate decimal(10,0);
Declare serviceProviderNameUpdate varchar(255);

Drop Temporary Table IF Exists ServiceProviderByID;
CREATE TEMPORARY TABLE IF NOT EXISTS ServiceProviderByID(ServiceProviderID int, PhoneNumber int, Address varchar(255), PreferredDistance decimal(10,0), ZipCode int, ServiceProviderName varchar(255));

Insert Into ServiceProviderByID Select ServiceProviderID,PhoneNumber,Address,PreferredDistance,ZipCode,ServiceProviderName from ServiceProviders where ServiceProviders.ServiceProviderID = ServiceProviderID limit 1;

if PhoneNumber <> null then set phoneNumberUpdate = PhoneNumber; else select PhoneNumber into phoneNumberUpdate from ServiceProviderByID limit 1; END IF;

if Address <> null then set addressUpdate = Address; else select Address into addressUpdate from ServiceProviderByID limit 1; END IF;

if ZipCode <> null then set zipCodeUpdate = ZipCode; else select ZipCode into zipCodeUpdate from ServiceProviderByID limit 1; END IF;

if preferredDistanceUpdate <> null then set preferredDistanceUpdate = PreferredDistance; else select PreferredDistance into preferredDistanceUpdate from ServiceProviderByID limit 1; END IF;

if ServiceProviderName <> null then set serviceProviderNameUpdate = ServiceProviderName; else select ServiceProviderName into serviceProviderNameUpdate from ServiceProviderByID limit 1; END IF;

DROP TEMPORARY TABLE IF EXISTS ServiceProviderByID;

UPDATE ServiceProviders SET PhoneNumber = phoneNumberUpdate, Address = addressUpdate, ZipCode = zipCodeUpdate, PreferredDistance = preferredDistanceUpdate, ServiceProviderName = serviceProviderNameUpdate Where ServiceProviders.ServiceProviderID = ServiceProviderID;
Select * from ServiceProviders where ServiceProviders.ServiceProviderID = ServiceProviderID limit 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `updateUser` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `updateUser`(IN UserID int, Email varchar(255), Pass varchar(255))
BEGIN
Declare emailUpdate varchar(255);
Declare passUpdate varchar(255);
CREATE TEMPORARY TABLE UserByID Select * from Users where UserID = UserID limit 1;
if Email <> null then set emailUpdate = Email; else set emailUpdate = UserByID.Email; END IF;
if Pass <> null then set passUpdate = Pass; else set passUpdate = UserByID.Pass; END IF;
Update Users Set Email = emailUpdate, Pass = passUpdate;
Select * from Users where UserID = UserByID.UserID;  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-14 16:49:05
