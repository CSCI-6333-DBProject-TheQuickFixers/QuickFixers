CREATE DATABASE  IF NOT EXISTS `quickFixers` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `quickFixers`;
-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: db-quickfixers.cffhy94odwbg.us-east-1.rds.amazonaws.com    Database: quickFixers
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Dumping routines for database 'quickFixers'
--
/*!50003 DROP PROCEDURE IF EXISTS `CreateSPServicesOffered` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `CreateSPServicesOffered`(SPID int, STID int, ServFee decimal(10,0))
BEGIN

INSERT INTO quickFixers.ServicesOffered (ServiceProviderID, ServiceTypeID, ServiceFee)
VALUES (SPID, STID, ServFee);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `CreateSPWorkSchedule` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `CreateSPWorkSchedule`(SPID int, WeekDay varchar(255), SPstart varchar(255), SPend varchar(255), TZ varchar(255))
BEGIN

INSERT INTO quickFixers.ServiceProviderAvailability (ServiceProviderID, DayoftheWeek, StartTime, EndTime, TimeZone)
VALUES (SPID, WeekDay, SPstart, SPend, TZ);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DeleteSPServicesOffered` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `DeleteSPServicesOffered`(SOID int)
BEGIN

DELETE FROM quickFixers.ServicesOffered
WHERE ServiceOfferedID = SOID;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DeleteSPWorkSchedule` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `DeleteSPWorkSchedule`(AvailID int)
BEGIN

DELETE FROM quickFixers.ServiceProviderAvailability
WHERE AvailabilityID = AvailID;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `deleteUser` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `deleteUser`(IN UserID int, OUT Success boolean)
BEGIN
Declare userCount int;
DELETE FROM Users Where Users.UserID = UserID;
Select Count(*) into userCount from Users where Users.UserID = UserID; 
if userCount < 1 then Set Success = True;
Else Set Success = False;
END IF; 
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `dummyWorkSchedule` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `dummyWorkSchedule`()
BEGIN
SELECT DayoftheWeek, StartTime, EndTime, TimeZone
FROM quickFixers.ServiceProviderAvailability
WHERE ServiceProviderID = 12
ORDER BY FIELD(DayoftheWeek, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday');
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `insertClient` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `insertClient`(IN UserID int, PhoneNumber varchar(255), Address varchar(255), ZipCode int, ClientName varchar(255))
BEGIN
insert into Clients (UserID, PhoneNumber, Address, ZipCode, ClientName) values (UserID, PhoneNumber,Address, ZipCode, ClientName);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `InsertPayment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `InsertPayment`(IN InputServiceProviderID int, InputClientID int, InputServiceOfferedID int, InputServiceDate DateTime, 
InputServiceAddress varchar(255), InputPaymentAmount decimal(10,2), InputApproved bit(1), InputPaymentDate DateTime, out Success int, out FailedMessage varchar(255))
BEGIN
Declare varScheduleServiceID int;
Declare varInvoiceID int;
Set varScheduleServiceID = 0;
Set varInvoiceID = 0;
Set Success = 1;
Set FailedMessage = "";
Insert into ScheduledServices (ServiceProviderID, ClientID, ServiceOfferedID, ServiceDate, ServiceAddress) 
Values (InputServiceProviderID, InputClientID, InputServiceOfferedID, InputServiceDate, InputServiceAddress);


select ScheduledServiceID into varScheduleServiceID from ScheduledServices where 
ServiceProviderID = InputServiceProviderID and ClientID = InputClientID and 
ServiceOfferedID = InputServiceOfferedID and ServiceDate = InputServiceDate and ServiceAddress = InputServiceAddress limit 1;

if varScheduleServiceID > 0 THEN
Insert Into Invoices (ClientID, ServiceProviderID, ScheduledServiceID) Values (InputClientID, InputServiceProviderID, varScheduleServiceID); 
select InvoiceID into varInvoiceID from Invoices where ClientID = InputClientID and ServiceProviderID = InputServiceProviderID and ScheduledServiceID = varScheduleServiceID limit 1;
Else
Set Success = 0;
Set FailedMessage = "Failed Creating Invoice, No Scheduled Service Found";
END IF;
 
  
if varInvoiceID > 0 Then 
Insert into Payments (InvoiceID, PaymentAmount, Approved, PaymentDate) Values (varInvoiceID,InputPaymentAmount, InputApproved, InputPaymentDate); 
Else
Set Success = 0;
Set FailedMessage = "Failed Creating Payment, No Invoice Found";
END IF;
 
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `insertServiceProvider` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `insertServiceProvider`(IN UserID int, PhoneNumber varchar(255), Address varchar(255), Zip int, PreferredDistance decimal(10,0), ServiceProviderName varchar(255))
BEGIN
insert into ServiceProviders (UserID, PhoneNumber, Address, PreferredDistance, ZipCode, ServiceProviderName) values 
(UserID, PhoneNumber, Address, PreferredDistance, Zip, ServiceProviderName);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `InsertServiceReview` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `InsertServiceReview`(IN ServiceProviderID int, PaymentID int, ServiceTypeID int, BriefReview varchar(255), Rating int)
BEGIN
Insert into ServiceReviews values (ServiceProviderID, PaymentID, ServiceTypeID, BriefReview, Rating);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `insertUser` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `insertUser`(IN Email varchar(255), Pass varchar(255), PhoneNumber varchar(255),
 Address varchar(255), ZipCode int, PreferredDistance decimal(10,0), UserTypeID int, UName varchar(255), out NewUserID int, out Success boolean)
BEGIN
Declare NewUserCreatedID int;
Set Success = False;

IF UserTypeID > 0 then insert into Users(Email, Pass, UserTypeID) values (Email, Pass, UserTypeID);
select UserID into NewUserCreatedID from Users where Users.Email = Email and Users.Pass = Pass and Users.UserTypeID = UserTypeID Limit 1;

CASE 
WHEN UserTypeID = 1 then
call quickFixers.insertClient(NewUserCreatedID,PhoneNumber,Address,ZipCode,UName);
Set Success = True;
Set NewUserID = NewUserCreatedID;

WHEN UserTypeID = 2 then 
call quickFixers.insertServiceProvider(NewUserCreatedID,PhoneNumber,Address,ZipCode,PreferredDistance,UName);
Set Success = True;
Set NewUserID = NewUserCreatedID;
ELSE 
Set NewUserID = -1;
Set Success = False;

END CASE;

ELSE
Set NewUserID = -1;
Set Success = False;
END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `selData` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `selData`()
BEGIN
select * from TestTable order by id desc;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SelectInvoices` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `SelectInvoices`(IN UserID int, UserTypeID int)
BEGIN
 Case
When UserTypeID = 1 then
SELECT InvoiceID, ClientID, ServiceProviderID, ScheduledServiceID
FROM quickFixers.Invoices
WHERE ClientID = UserID;
When UserTypeID = 2 then
SELECT InvoiceID, ClientID, ServiceProviderID, ScheduledServiceID
FROM quickFixers.Invoices
WHERE ServiceProviderID = UserID; 
End Case;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `selectLoggedUser` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `selectLoggedUser`(IN UserID int, UserTypeID int, IsLoggedIn boolean)
BEGIN
if isLoggedIn = true then

If UserTypeID = 1 THEN 
SELECT * From Users U natural join Clients where U.UserID = UserID limit 1;

ELSEIF UserTypeID = 2 THEN

SELECT * From Users U natural join ServiceProviders where U.UserID = UserID limit 1;
END IF;

END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SelectPastServices` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `SelectPastServices`(IN UserID int, UserTypeID int)
BEGIN
Case
when UserTypeID = 1 then

SELECT *
FROM quickFixers.ScheduledServices
WHERE ClientID = UserID
AND ServiceDate < NOW();

when UserTypeID = 2 then
SELECT *
FROM quickFixers.ScheduledServices
WHERE ServiceProviderID = UserID
AND ServiceDate < NOW();
End Case;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SelectScheduledServices` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `SelectScheduledServices`(IN UserID int, UserTypeID int)
BEGIN

Case
when UserTypeID = 1 then
SELECT *
FROM quickFixers.ScheduledServices
WHERE ClientID = UserID
AND ServiceDate >= NOW();

when UserTypeID = 2 then
SELECT *
FROM quickFixers.ScheduledServices
WHERE ServiceProviderID = UserID
AND ServiceDate >= NOW();

End case;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `selectServices` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `selectServices`(IN ServiceTypeID int(15), ServiceProviderName varchar(255), ZipCode int(10), PreferredDistance int(5), DayOfTheWeek varchar(8), ServiceTime time)
BEGIN
	select distinct s.ServiceTypeID, s.ServiceOfferedID, st.ServiceTypeName, s.ServiceProviderID, sp.ServiceProviderName, sp.ZipCode, sp.PreferredDistance, s.ServiceFee
		from ServicesOffered s 
			inner join ServiceProviders sp
				on sp.ServiceProviderID = s.ServiceProviderID
			inner join ServiceProviderAvailability sa
				on sa.ServiceProviderID = s.ServiceProviderID
			inner join ServiceTypes st
				on st.ServiceTypeID = s.ServiceTypeID
			where s.ServiceTypeID = ServiceTypeID and 
				(sp.ServiceProviderName = ServiceProviderName or
				sp.ZipCode = ZipCode or
                sp.PreferredDistance > PreferredDistance or
                sa.DayoftheWeek = DayOfTheWeek or
                ServiceTime between sa.StartTime and sa.EndTime);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `selectServicesByUserID` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `selectServicesByUserID`(IN UserID int(50))
BEGIN
	select s.ScheduledServiceID, s.ServiceProviderID, sp.ServiceProviderName, s.ClientID, c.ClientName, s.ServiceOfferedID, st.ServiceTypeName,
		s.ServiceDate, s.ServiceAddress, so.ServiceFee
		from ScheduledServices s 
        inner join Clients c 
			on s.ClientID = c.ClientID
		inner join Users u
			on u.UserID = c.UserID
        inner join ServiceProviders sp
			on sp.ServiceProviderID = s.ServiceProviderID
        inner join ServicesOffered so on
			so.ServiceOfferedID = s.ServiceOfferedID
        inner join ServiceTypes st
			on st.ServiceTypeID = so.ServiceTypeID
		where
			c.UserID = UserID;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `selectServiceTypes` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `selectServiceTypes`()
BEGIN
select * from ServiceTypes;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `selectUser` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `selectUser`(IN Email varchar(255), UserPassword varchar(255))
BEGIN
DECLARE loginClient int;
DECLARE loginServiceProvider int;
DROP TEMPORARY TABLE IF EXISTS LoginUserClient;
CREATE TEMPORARY TABLE IF NOT EXISTS LoginUserClient(UserID int, Email varchar(255), Pass varchar(255), UserTypeID int, ClientID int, PhoneNumber int, Address varchar(255), ZipCode int, UName varchar(255));

INSERT INTO LoginUserClient SELECT * From Users U natural join Clients where U.Email = Email and U.Pass = UserPassword limit 1;
SELECT COUNT(*) into loginClient from LoginUserClient;

DROP TEMPORARY TABLE IF EXISTS LoginUserServiceProvider;
CREATE TEMPORARY TABLE IF NOT EXISTS LoginUserServiceProvider(UserID int, Email varchar(255), Pass varchar(255), UserTypeID int, ServiceProviderID int, PhoneNumber int, Address varchar(255), PreferredDistance decimal(10,0), ZipCode int, UName varchar(255));
INSERT INTO LoginUserServiceProvider SELECT * From Users U natural join ServiceProviders where U.Email = Email and U.Pass = UserPassword limit 1;
SELECT COUNT(*) Into loginServiceProvider from LoginUserServiceProvider;

IF loginClient = 1 THEN
SELECT * FROM LoginUserClient;
ElseIF loginServiceProvider = 1 THEN
SELECT * FROM LoginUserServiceProvider;
END IF;
DROP TEMPORARY TABLE IF EXISTS LoginUserClient;
DROP TEMPORARY TABLE IF EXISTS LoginUserServiceProvider;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `selectUserByUserID` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `selectUserByUserID`(IN UserID int(50))
BEGIN
	SELECT * FROM Users WHERE Users.UserID = UserID;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `selectUserTypes` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `selectUserTypes`()
BEGIN
select * from UserTypes;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SelSPInvoices` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `SelSPInvoices`(SPUserID int)
BEGIN

SELECT I.InvoiceID, I.ClientID, I.ServiceProviderID, I.ScheduledServiceID, C.ClientName, SP.ServiceProviderName, SS.ServiceDate, SS.ServiceAddress, SO.ServiceFee, ST.ServiceTypeName 
FROM quickFixers.Invoices as I
JOIN quickFixers.Clients as C
ON I.ClientID = C.ClientID
JOIN quickFixers.ServiceProviders as SP
ON I.ServiceProviderID = SP.ServiceProviderID
JOIN quickFixers.ScheduledServices as SS
ON I.ScheduledServiceID = SS.ScheduledServiceID
JOIN quickFixers.ServicesOffered as SO
ON SS.ServiceOfferedID = SO.ServiceOfferedID
JOIN quickFixers.ServiceTypes as ST
ON SO.ServiceTypeID = ST.ServiceTypeID
WHERE I.ServiceProviderID = SPUserID;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SelSPPastServices` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `SelSPPastServices`(SPUserID int)
BEGIN
SELECT SS.ScheduledServiceID, SS.ServiceProviderID, SS.ClientID, SS.ServiceOfferedID, SS.ServiceDate, SS.ServiceAddress, SP.ServiceProviderName, C.ClientName, SO.ServiceFee, ST.ServiceTypeName
FROM quickFixers.ScheduledServices AS SS
JOIN quickFixers.ServiceProviders AS SP
ON SS.ServiceProviderID = SP.ServiceProviderID
JOIN quickFixers.Clients AS C
ON SS.ClientID = C.ClientID
JOIN quickFixers.ServicesOffered AS SO
ON SS.ServiceOfferedID = SO.ServiceOfferedID
JOIN quickFixers.ServiceTypes as ST
ON SO.ServiceTypeID = ST.ServiceTypeID
WHERE SS.ServiceProviderID = SPUserID
AND SS.ServiceDate < NOW();
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SelSPScheduledServices` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `SelSPScheduledServices`(SPUserID int)
BEGIN
SELECT SS.ScheduledServiceID, SS.ServiceProviderID, SS.ClientID, SS.ServiceOfferedID, SS.ServiceDate, SS.ServiceAddress, SP.ServiceProviderName, C.ClientName, SO.ServiceFee, ST.ServiceTypeName
FROM quickFixers.ScheduledServices AS SS
JOIN quickFixers.ServiceProviders AS SP
ON SS.ServiceProviderID = SP.ServiceProviderID
JOIN quickFixers.Clients AS C
ON SS.ClientID = C.ClientID
JOIN quickFixers.ServicesOffered AS SO
ON SS.ServiceOfferedID = SO.ServiceOfferedID
JOIN quickFixers.ServiceTypes as ST
ON SO.ServiceTypeID = ST.ServiceTypeID
WHERE SS.ServiceProviderID = SPUserID
AND SS.ServiceDate >= NOW();
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SelSPServicesOffered` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `SelSPServicesOffered`(SPUserID int)
BEGIN
SELECT S.ServiceOfferedID, T.ServiceTypeName, S.ServiceFee
FROM ServicesOffered S natural join ServiceTypes T
WHERE S.ServiceTypeID = T.ServiceTypeID
AND S.ServiceProviderID = SPUserID;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SelSPUser` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `SelSPUser`(UserID int)
BEGIN
SELECT SP.ServiceProviderID, SP.PhoneNumber, SP.Address, SP.PreferredDistance, SP.ZipCode, SP.ServiceProviderName
FROM quickFixers.ServiceProviders AS SP
WHERE SP.UserID = UserID;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SelSPWorkSchedule` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `SelSPWorkSchedule`(SPUserID int)
BEGIN
SELECT AvailabilityID, DayoftheWeek, StartTime, EndTime, TimeZone
FROM quickFixers.ServiceProviderAvailability
WHERE ServiceProviderID = SPUserID
ORDER BY FIELD(DayoftheWeek, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday');
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `updateClient` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `updateClient`(IN ClientID int,PhoneNumber int, Address varchar(255), ZipCode int, UName varchar(255))
BEGIN
Declare phoneNumberUpdate int;
Declare addressUpdate varchar(255);
Declare zipCodeUpdate int;
Declare nameUpdate varchar(255);
DROP TEMPORARY TABLE IF EXISTS ClientByID;
CREATE TEMPORARY TABLE IF NOT EXISTS ClientByID(ClientID int, PhoneNumber int, Address varchar(255), ZipCode int, ClientName varchar(255));
Insert Into ClientByID Select ClientID,PhoneNumber,Address,ZipCode,ClientName from Clients where Clients.ClientID = ClientID limit 1;
if PhoneNumber <> null then set phoneNumberUpdate = PhoneNumber; else select ClientByID.PhoneNumber into phoneNumberUpdate from ClientByID limit 1; END IF;
if Address <> null then set addressUpdate = Address; else select ClientByID.Address into addressUpdate from ClientByID limit 1; END IF;
if ZipCode <> null then set zipCodeUpdate = ZipCode; else select ClientByID.ZipCode into zipCodeUpdate from ClientByID limit 1; END IF;
if UName <> null then set nameUpdate = UName; else select ClientByID.ClientName into nameUpdate from ClientByID limit 1; END IF;
DROP TEMPORARY TABLE IF EXISTS ClientByID;
UPDATE Clients SET PhoneNumber = phoneNumberUpdate, Address = addressUpdate, ZipCode = zipCodeUpdate, ClientName = nameUpdate Where Clients.ClientID = ClientID;
Select * from Clients where Clients.ClientID = ClientID limit 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `updateServiceProvider` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `updateServiceProvider`(IN ServiceProviderID int, PhoneNumber int, Address varchar(255), PreferredDistance decimal(10,0), ZipCode int, ServiceProviderName varchar(255))
BEGIN
Declare phoneNumberUpdate int;
Declare addressUpdate varchar(255);
Declare zipCodeUpdate int;
Declare preferredDistanceUpdate decimal(10,0);
Declare serviceProviderNameUpdate varchar(255);

Drop Temporary Table IF Exists ServiceProviderByID;
CREATE TEMPORARY TABLE IF NOT EXISTS ServiceProviderByID(ServiceProviderID int, PhoneNumber int, Address varchar(255), PreferredDistance decimal(10,0), ZipCode int, ServiceProviderName varchar(255));

Insert Into ServiceProviderByID Select ServiceProviderID,PhoneNumber,Address,PreferredDistance,ZipCode,ServiceProviderName from ServiceProviders where ServiceProviders.ServiceProviderID = ServiceProviderID limit 1;

if PhoneNumber <> null then set phoneNumberUpdate = PhoneNumber; else select PhoneNumber into phoneNumberUpdate from ServiceProviderByID limit 1; END IF;

if Address <> null then set addressUpdate = Address; else select Address into addressUpdate from ServiceProviderByID limit 1; END IF;

if ZipCode <> null then set zipCodeUpdate = ZipCode; else select ZipCode into zipCodeUpdate from ServiceProviderByID limit 1; END IF;

if preferredDistanceUpdate <> null then set preferredDistanceUpdate = PreferredDistance; else select PreferredDistance into preferredDistanceUpdate from ServiceProviderByID limit 1; END IF;

if ServiceProviderName <> null then set serviceProviderNameUpdate = ServiceProviderName; else select ServiceProviderName into serviceProviderNameUpdate from ServiceProviderByID limit 1; END IF;

DROP TEMPORARY TABLE IF EXISTS ServiceProviderByID;

UPDATE ServiceProviders SET PhoneNumber = phoneNumberUpdate, Address = addressUpdate, ZipCode = zipCodeUpdate, PreferredDistance = preferredDistanceUpdate, ServiceProviderName = serviceProviderNameUpdate Where ServiceProviders.ServiceProviderID = ServiceProviderID;
Select * from ServiceProviders where ServiceProviders.ServiceProviderID = ServiceProviderID limit 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `updateUser` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`quickFixersAdmin`@`%` PROCEDURE `updateUser`(IN UserID int, Email varchar(255), Pass varchar(255))
BEGIN
Declare emailUpdate varchar(255);
Declare passUpdate varchar(255);
CREATE TEMPORARY TABLE UserByID Select * from Users where UserID = UserID limit 1;
if Email <> null then set emailUpdate = Email; else set emailUpdate = UserByID.Email; END IF;
if Pass <> null then set passUpdate = Pass; else set passUpdate = UserByID.Pass; END IF;
Update Users Set Email = emailUpdate, Pass = passUpdate;
Select * from Users where UserID = UserByID.UserID;  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-14 16:47:20
