CREATE DATABASE  IF NOT EXISTS `quickFixers` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `quickFixers`;
-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: db-quickfixers.cffhy94odwbg.us-east-1.rds.amazonaws.com    Database: quickFixers
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `ServiceProviders`
--

DROP TABLE IF EXISTS `ServiceProviders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ServiceProviders` (
  `ServiceProviderID` int NOT NULL AUTO_INCREMENT,
  `UserID` int NOT NULL,
  `PhoneNumber` varchar(255) DEFAULT NULL,
  `Address` varchar(255) NOT NULL,
  `PreferredDistance` decimal(10,0) DEFAULT NULL,
  `ZipCode` int NOT NULL,
  `ServiceProviderName` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ServiceProviderID`),
  KEY `ServiceProviders_ibfk_1` (`UserID`),
  CONSTRAINT `ServiceProviders_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `Users` (`UserID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ServiceProviders`
--

LOCK TABLES `ServiceProviders` WRITE;
/*!40000 ALTER TABLE `ServiceProviders` DISABLE KEYS */;
INSERT INTO `ServiceProviders` VALUES (4,23,'555555','123 ave',5555,78543,'J Plumbing'),(7,25,'2222222','5634 Buckeye Ct',30,78526,'Zapper Electrric'),(10,24,'444444','223 st',4343,78542,'McAllen AC Repairs'),(11,29,'123434','123 from Prjoect',32323,78555,'Weslaco Repairs'),(12,49,'9561234444','63 Coveway St',20,78521,'Mathew Sosa'),(21,68,'5555555','123 st',848484,78444,'Some provider'),(26,73,'5555555555','123 Service Ave',10,55555,'Service Provider'),(27,77,'2102222222','123 Testtest St',15,78543,'Zapper Home Repair'),(28,78,'2323233','123 st',33,3232,'Test sp'),(29,79,'5555555555','123 Test Ave',20,78521,'Charles Smith'),(30,80,'9565555555','123 Test St',30,78521,'Brownsville Mechanic'),(31,81,'9562321111','123 Test Blvd',20,78521,'Valley AC Repair'),(32,82,'9561234444','123 Test St',50,78521,'General Repairs 24/7'),(33,83,'4444444','123 st',20,443444,'New SP'),(34,84,'9567777777','123 Test',35,78521,'Test Test'),(35,86,'13323233','123 st av',10,323333,'Test SP');
/*!40000 ALTER TABLE `ServiceProviders` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-14 16:47:08
