CREATE DATABASE  IF NOT EXISTS `quickFixers` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `quickFixers`;
-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: db-quickfixers.cffhy94odwbg.us-east-1.rds.amazonaws.com    Database: quickFixers
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `Payments`
--

DROP TABLE IF EXISTS `Payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Payments` (
  `PaymentID` int NOT NULL AUTO_INCREMENT,
  `InvoiceID` int NOT NULL,
  `PaymentAmount` decimal(10,2) NOT NULL,
  `Approved` bit(1) NOT NULL DEFAULT b'1',
  `PaymentDate` datetime NOT NULL,
  PRIMARY KEY (`PaymentID`),
  KEY `InvoiceID` (`InvoiceID`),
  CONSTRAINT `Payments_ibfk_1` FOREIGN KEY (`InvoiceID`) REFERENCES `Invoices` (`InvoiceID`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Payments`
--

LOCK TABLES `Payments` WRITE;
/*!40000 ALTER TABLE `Payments` DISABLE KEYS */;
INSERT INTO `Payments` VALUES (2,3,131.00,_binary '','2022-05-10 00:00:00'),(3,3,76.00,_binary '','2022-05-10 00:00:00'),(4,3,75.50,_binary '','2022-05-10 00:00:00'),(5,6,120.50,_binary '\0','2022-05-10 15:01:50'),(13,13,100.50,_binary '','2022-05-10 19:36:12'),(14,15,50.00,_binary '\0','2022-05-11 00:33:25'),(15,15,50.00,_binary '\0','2022-05-11 00:35:41'),(16,15,50.00,_binary '\0','2022-05-11 00:36:28'),(17,15,50.00,_binary '','2022-05-11 00:37:22'),(18,19,200.00,_binary '','2022-05-11 01:31:21'),(19,20,200.00,_binary '','2022-05-11 01:34:35'),(20,21,300.00,_binary '\0','2022-05-11 01:39:39'),(21,22,200.00,_binary '','2022-05-11 01:40:30'),(22,23,2.00,_binary '','2022-05-11 06:42:41'),(23,24,150.00,_binary '','2022-05-11 06:46:40'),(24,25,50.00,_binary '\0','2022-05-11 01:52:26'),(25,26,200.00,_binary '','2022-05-11 06:57:30'),(26,27,200.00,_binary '','2022-05-11 02:11:01'),(27,28,200.00,_binary '','2022-05-11 07:21:49'),(28,29,200.00,_binary '','2022-05-11 07:22:03'),(29,30,200.00,_binary '','2022-05-11 07:24:43'),(30,31,200.00,_binary '','2022-05-11 20:29:38'),(31,32,50.00,_binary '\0','2022-05-11 20:30:37'),(32,33,200.00,_binary '\0','2022-05-14 20:26:08');
/*!40000 ALTER TABLE `Payments` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-14 16:47:04
