CREATE DATABASE  IF NOT EXISTS `quickFixers` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `quickFixers`;
-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: db-quickfixers.cffhy94odwbg.us-east-1.rds.amazonaws.com    Database: quickFixers
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `ServicesOffered`
--

DROP TABLE IF EXISTS `ServicesOffered`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ServicesOffered` (
  `ServiceOfferedID` int NOT NULL AUTO_INCREMENT,
  `ServiceProviderID` int NOT NULL,
  `ServiceTypeID` int NOT NULL,
  `ServiceFee` decimal(10,2) NOT NULL,
  PRIMARY KEY (`ServiceOfferedID`),
  KEY `ServiceTypeID` (`ServiceTypeID`),
  KEY `ServicesOffered_ibfk_1` (`ServiceProviderID`),
  CONSTRAINT `ServicesOffered_ibfk_1` FOREIGN KEY (`ServiceProviderID`) REFERENCES `ServiceProviders` (`ServiceProviderID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ServicesOffered_ibfk_2` FOREIGN KEY (`ServiceTypeID`) REFERENCES `ServiceTypes` (`ServiceTypeID`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ServicesOffered`
--

LOCK TABLES `ServicesOffered` WRITE;
/*!40000 ALTER TABLE `ServicesOffered` DISABLE KEYS */;
INSERT INTO `ServicesOffered` VALUES (1,12,1,50.00),(2,12,3,75.00),(5,29,1,200.00),(6,29,2,300.00),(7,29,3,400.00),(8,29,4,400.00),(9,29,5,100.00),(10,29,6,150.00),(11,29,7,200.00),(12,29,8,300.00),(13,29,9,100.00),(14,29,10,200.00),(15,29,11,150.00),(16,30,6,300.00),(17,31,7,500.00),(18,32,1,200.00),(19,32,2,200.00),(20,32,3,200.00),(21,32,4,200.00),(23,32,5,200.00),(24,32,6,200.00),(25,32,7,200.00),(26,32,8,200.00),(27,32,9,200.00),(28,32,10,200.00),(29,32,11,200.00),(30,12,10,100.00),(31,12,7,100.00),(36,12,2,400.00),(38,34,2,300.00),(39,35,6,2.00),(41,12,5,200.00);
/*!40000 ALTER TABLE `ServicesOffered` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-14 16:47:12
