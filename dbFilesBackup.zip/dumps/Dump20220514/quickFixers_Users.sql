CREATE DATABASE  IF NOT EXISTS `quickFixers` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `quickFixers`;
-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: db-quickfixers.cffhy94odwbg.us-east-1.rds.amazonaws.com    Database: quickFixers
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `Users`
--

DROP TABLE IF EXISTS `Users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Users` (
  `UserID` int NOT NULL AUTO_INCREMENT,
  `Email` varchar(255) NOT NULL,
  `Pass` varchar(255) NOT NULL,
  `UserTypeID` int DEFAULT NULL,
  PRIMARY KEY (`UserID`),
  UNIQUE KEY `Email_UNIQUE` (`Email`),
  KEY `UserTypeID_idx` (`UserTypeID`),
  CONSTRAINT `UserTypeID` FOREIGN KEY (`UserTypeID`) REFERENCES `UserTypes` (`UserTypeID`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Users`
--

LOCK TABLES `Users` WRITE;
/*!40000 ALTER TABLE `Users` DISABLE KEYS */;
INSERT INTO `Users` VALUES (21,'testClientProvider@test.com','pass3123',1),(22,'testClientProvider2@test.com','pass3123',1),(23,'testclient2@test.com','dzHb7w5pO64BFA9PAFduhqKnueY=',1),(24,'client1@test.com','cRDtpNCeBiql5KOQsKVyrA0sAiA=',1),(25,'sp1@test.com','1234',2),(26,'testClient@email.com','000jjjjj',1),(28,'testClient2@email.com','000jjjjj',1),(29,'camefromproject@user.com','123fromproject',2),(36,'testClient417@email.com','1234',1),(37,'testclient417two@email.com','124',1),(46,'clientproject@email.com','pass123',1),(48,'iminciass@email.com','1234',1),(49,'sptestmatt@email.com','QL0AFWMIX8NRZTKeof9cXsvbvu8=',2),(50,'testclientfromPJ@email.com','pass123',1),(52,'quickFixerClient@test.com','client123',1),(53,'test123456@test.com','password123',1),(54,'test987@test.com','123456',1),(55,'test555@test.com','password123',1),(62,'test2468@nowhere.com','Test12345',1),(63,'fakeemail@nowhere.com','Test123',1),(68,'serviceProviderPro@email.com','qv3COHDsvNPVV7ZCOomCE04Xkn4=',2),(73,'serviceProvider@email.com','j14SXLjHscZEmIdAXqwHVeFslxo=',2),(74,'client@email.com','lKNvACQUUjzQDoXR89pxdei9VEM=',1),(76,'test@test.com','qv3COHDsvNPVV7ZCOomCE04Xkn4=',1),(77,'partctest@email.com','123',2),(78,'testSP@email.com','qv3COHDsvNPVV7ZCOomCE04Xkn4=',2),(79,'dummysp2@email.com','QL0AFWMIX8NRZTKeof9cXsvbvu8=',2),(80,'dummysp3@email.com','QL0AFWMIX8NRZTKeof9cXsvbvu8=',2),(81,'dummysp4@email.com','QL0AFWMIX8NRZTKeof9cXsvbvu8=',2),(82,'dummysp5@email.com','QL0AFWMIX8NRZTKeof9cXsvbvu8=',2),(83,'newServiceProvider@gmail.com','qv3COHDsvNPVV7ZCOomCE04Xkn4=',2),(84,'spdummy123@email.com','QL0AFWMIX8NRZTKeof9cXsvbvu8=',2),(85,'TestClient1@email.com','y/2sYAj5yrQIN4TL0YdPdmGNKpc=',1),(86,'testSP@sp.com','y/2sYAj5yrQIN4TL0YdPdmGNKpc=',2);
/*!40000 ALTER TABLE `Users` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-14 16:47:14
